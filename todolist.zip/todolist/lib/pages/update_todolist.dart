// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print

import 'package:flutter/material.dart';

// http method package
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';

class UpdatePage extends StatefulWidget {
  final v1, v2, v3;
  const UpdatePage(this.v1, this.v2, this.v3);

  @override
  _UpdatePageState createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  var _v1, _v2, _v3;

  @override
  void initState() {
    super.initState();
    _v1 = widget.v1; //id
    _v2 = widget.v2; //title
    _v3 = widget.v3; //detail
    todoTitle.text = _v2;
    todoDetail.text = _v3;
  }

  TextEditingController todoTitle = TextEditingController();
  TextEditingController todoDetail = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('แก้ไขรายการ'),
          actions: [
            IconButton(
                onPressed: () {
                  print("Delete ID: $_v1");
                  deleteTodo();
                  Navigator.pop(context, 'delete');
                },
                icon: Icon(
                  Icons.delete,
                  color: Colors.red[100],
                )),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ListView(
            children: [
              TextField(
                  controller: todoTitle,
                  decoration: InputDecoration(
                      labelText: 'รายการที่ต้องทำ',
                      border: OutlineInputBorder())),
              SizedBox(
                height: 30,
              ),
              TextField(
                controller: todoDetail,
                decoration: InputDecoration(
                    labelText: 'รายละเอียด', border: OutlineInputBorder()),
                minLines: 4,
                maxLines: 8,
              ),
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(100, 0, 100, 0),
                child: ElevatedButton(
                    onPressed: () {
                      print('------');
                      print('title: ${todoTitle.text}');
                      print('detail: ${todoDetail.text}');
                      updateTodo();

                      final snackBar =
                          SnackBar(content: const Text('update เรียบร้อยแล้ว'));

                      // Find the ScaffoldMessenger in the widget tree
                      // and use it to show a SnackBar.
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);

                      //setState(() {
                      //  todoTitle.clear();
                      //  todoDetail.clear();
                      //});
                    },
                    child: Text("แก้ไข"),
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(Colors.amber[700]),
                      padding: MaterialStateProperty.all(
                          EdgeInsets.fromLTRB(50, 20, 50, 20)),
                      textStyle:
                          MaterialStateProperty.all(TextStyle(fontSize: 30)),
                    )),
              ),
            ],
          ),
        ));
  }

  Future updateTodo() async {
    //var url = Uri.http('07bd-49-230-26-247.ngrok.io', '/api/post-TodoList');
    var url = Uri.http('192.168.43.161:8000', '/api/update-TodoList/$_v1');

    Map<String, String> header = {
      "Content-Type": "application/json",
    };
    String jsondata =
        '{"title":"${todoTitle.text}", "detail":"${todoDetail.text}"}';
    var response = await http.put(url, headers: header, body: jsondata);
    print('----------result----------');
    print(response.body);
  }

  Future deleteTodo() async {
    //var url = Uri.http('07bd-49-230-26-247.ngrok.io', '/api/post-TodoList');
    var url = Uri.http('192.168.43.161:8000', '/api/delete-TodoList/$_v1');

    Map<String, String> header = {
      "Content-Type": "application/json",
    };
    String jsondata =
        '{"title":"${todoTitle.text}", "detail":"${todoDetail.text}"}';
    var response = await http.delete(url, headers: header);
    print('----------result----------');
    print(response.body);
  }
}
