// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print

import 'package:flutter/material.dart';
import 'package:todolist/pages/add.dart';
import 'package:todolist/pages/update_todolist.dart';

// http method package
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';

class TodoList extends StatefulWidget {
  //const TodoLoist({ Key? key }) : super(key: key);

  @override
  _TodoLoistState createState() => _TodoLoistState();
}

class _TodoLoistState extends State<TodoList> {
  List todoListItems = ['A', 'B', 'C', 'D'];

  @override
  void initState() {
    super.initState();
    getTodoList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(
                    context, MaterialPageRoute(builder: (context) => AddPage()))
                .then((value) {
              setState(() {
                getTodoList();
              });
            });
          },
          child: Icon(Icons.add),
        ),
        appBar: AppBar(
          title: Text('All Todo List'),
          actions: [
            IconButton(
                onPressed: () {
                  setState(() {
                    getTodoList();
                  });
                },
                icon: Icon(
                  Icons.refresh,
                  color: Colors.white,
                )),
          ],
        ),
        body: todoListCreate());
  }

  Widget todoListCreate() {
    return ListView.builder(
        itemCount: todoListItems.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text("${todoListItems[index]['title']}"),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => UpdatePage(
                            todoListItems[index]['id'],
                            todoListItems[index]['title'],
                            todoListItems[index]['detail']))).then((value) {
                  setState(() {
                    if (value == 'delete') {
                      final snackBar = SnackBar(
                          content: const Text('ลบข้อมูลเรียบร้อยแล้ว'));

                      // Find the ScaffoldMessenger in the widget tree
                      // and use it to show a SnackBar.
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    }
                    getTodoList();
                  });
                });
              },
            ),
          );
        });
  }

  Future<void> getTodoList() async {
    List allTodo = [];
    var url = Uri.http('192.168.43.161:8000', '/api/all-TodoList');
    var response = await http.get(url);
    //var result = json.decode(response.body);
    var result = utf8.decode(response.bodyBytes);
    print(result);
    setState(() {
      todoListItems = jsonDecode(result);
    });
  }
}
