// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print

import 'package:flutter/material.dart';

// http method package
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';

class AddPage extends StatefulWidget {
  const AddPage({Key? key}) : super(key: key);

  @override
  _AddPageState createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {
  TextEditingController todoTitle = TextEditingController();
  TextEditingController todoDetail = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('เพิ่มรายการใหม่'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ListView(
            children: [
              TextField(
                  controller: todoTitle,
                  decoration: InputDecoration(
                      labelText: 'รายการที่ต้องทำ',
                      border: OutlineInputBorder())),
              SizedBox(
                height: 30,
              ),
              TextField(
                controller: todoDetail,
                decoration: InputDecoration(
                    labelText: 'รายละเอียด', border: OutlineInputBorder()),
                minLines: 4,
                maxLines: 8,
              ),
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(100, 0, 100, 0),
                child: ElevatedButton(
                    onPressed: () {
                      print('------');
                      print('title: ${todoTitle.text}');
                      print('detail: ${todoDetail.text}');
                      postTodo();

                      final snackBar =
                          SnackBar(content: const Text('add เรียบร้อยแล้ว'));

                      // Find the ScaffoldMessenger in the widget tree
                      // and use it to show a SnackBar.
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);

                      setState(() {
                        todoTitle.clear();
                        todoDetail.clear();
                      });
                    },
                    child: Text("เพิ่ม"),
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(Colors.amber[700]),
                      padding: MaterialStateProperty.all(
                          EdgeInsets.fromLTRB(50, 20, 50, 20)),
                      textStyle:
                          MaterialStateProperty.all(TextStyle(fontSize: 30)),
                    )),
              ),
            ],
          ),
        ));
  }

  Future postTodo() async {
    //var url = Uri.http('07bd-49-230-26-247.ngrok.io', '/api/post-TodoList');
    var url = Uri.http('192.168.43.161:8000', '/api/post-TodoList');

    Map<String, String> header = {
      "Content-Type": "application/json",
    };
    String jsondata =
        '{"title":"${todoTitle.text}", "detail":"${todoDetail.text}"}';
    var response = await http.post(url, headers: header, body: jsondata);
    print('----------result----------');
    print(response.body);
  }
}
